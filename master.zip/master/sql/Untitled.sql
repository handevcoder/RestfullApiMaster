use masterjava;
call masterjava.SP_GET_ALL_USER();
call masterjava.SP_GET_ALL_ROLE();

call masterjava.SP_INSERT_USER('hanif','iwansyah','@mail.com','1');
call masterjava.SP_INSERT_USER();


call masterjava.SP_INSERT_ROLE(2,'USER',1);
call masterjava.SP_INSERT_ROLE('ADMIN_SUPER','1');