package com.example.masterjava.exceptions;

public class ApiExceptionHandler {

}
