package com.example.masterjava.services;

import java.util.List;
import java.util.Optional;

import com.example.masterjava.dto.ProductDto;

public interface ProductService {
	List<ProductDto> findAll();
	Optional<ProductDto> findById(Long id);
	ProductDto create(ProductDto productDto);
	ProductDto update(ProductDto productDto);
	void deleteById(Long id);
}
