package com.example.masterjava.service;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import com.example.masterjava.entity.User;

public class UserImplement implements UserDao {
	private DataSource dataSource;
	private SimpleJdbcCall jdbcCall;
	
	public void setDataSource(DataSource ds) {
		this.dataSource = dataSource;
		this.jdbcCall = new SimpleJdbcCall(dataSource).withProcedureName("getAllUsers");
	}

	@Override
	public void create(Long id, String first_name, String last_name, String email, String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User getUser(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> listUsers() {
		// TODO Auto-generated method stub
		return null;
	}

}
