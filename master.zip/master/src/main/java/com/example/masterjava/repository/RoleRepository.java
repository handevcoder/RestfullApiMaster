package com.example.masterjava.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;


import com.example.masterjava.entity.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long>{
	@Procedure(name = "SP_GET_ALL_ROLE")
	List<Role> getAllRole();
}
