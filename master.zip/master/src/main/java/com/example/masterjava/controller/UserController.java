package com.example.masterjava.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.masterjava.entity.User;
import com.example.masterjava.exception.ResourceNotFoundException;
import com.example.masterjava.repository.UserRepository;

@RestController
public class UserController {
	@Autowired
	private UserRepository userRepository;
	
	@PostMapping("/users")
	public List<User> getAllUsers(){
		return this.userRepository.findAll();
	}
	
	@PostMapping("user/{id}")
	public User getUserById(@PathVariable(value = "id") Long userId){
		return this.userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
	}
	
	@PostMapping("user")
	public User createUser(@RequestBody User user){
		return this.userRepository.save(user);
	}
	
	@PutMapping("user/{id}")
	public User updateUser(@RequestBody User user, @PathVariable("id") Long userId){
		User existingUser = this.userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
		existingUser.setFirstName(user.getFirstName());
		existingUser.setLastName(user.getLastName());
		existingUser.setEmail(user.getEmail());
		existingUser.setStatus(user.getStatus());
		return this.userRepository.save(existingUser);
	}
	
	@DeleteMapping("user/{id}")
	public ResponseEntity<User> deleteUser(@PathVariable ("id") long userId){
		User existingUser = this.userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
		this.userRepository.delete(existingUser);
		return ResponseEntity.ok().build();
	}
	
}
