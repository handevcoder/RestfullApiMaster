package com.example.masterjava.entity;

import javax.persistence.Column;
//import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
//import javax.persistence.NamedStoredProcedureQueries;
//import javax.persistence.NamedStoredProcedureQuery;
//import javax.persistence.ParameterMode;
//import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table; 


@Table(name = "role")
@NamedStoredProcedureQueries({ 
	@NamedStoredProcedureQuery(name = "SP_GET_ALL_ROLE", procedureName = "SP_GET_ALL_ROLE")
})
//	,
//	@NamedStoredProcedureQuery(name = "SP_GET_ROLE_BYNAME", procedureName = "SP_GET_ROLE_BYNAME", 
//	parameters = { @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_NAME", type = String.class) })})
@Entity

public class Role {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@Column(name = "id")
	private Long id;
	
	@Column(name = "name")
	private String name;

	public Role() {
	}

	public Role(Long id, String name) {
		this.id = id;
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
