package com.example.masterjava.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import javax.validation.constraints.NotBlank;

public class ProductDto {
	private Long id;
	@NotBlank(message = "{Notblank.ProductDto.name}")
	private String name;
	private String decription;
	@NotBlank(message = "{Notblank.ProductDto.price}")
	private BigDecimal price;
	@NotBlank(message = "{Notblank.ProductDto.quantity}")
	private Long quantity;
	private OffsetDateTime createdAt;
	
	public Long getId() {
		return id;
	}
	public ProductDto setId(Long id) {
		this.id = id;
		return this;
	}
	public String getName() {
		return name;
	}
	public ProductDto setName(String name) {
		this.name = name;
		return this;
	}
	public String getDecription() {
		return decription;
	}
	public ProductDto setDecription(String decription) {
		this.decription = decription;
		return this;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public ProductDto setPrice(BigDecimal price) {
		this.price = price;
		return this;
	}
	public Long getQuantity() {
		return quantity;
	}
	public ProductDto setQuantity(Long quantity) {
		this.quantity = quantity;
		return this;
	}
	public OffsetDateTime getCreatedAt() {
		return createdAt;
	}
	public ProductDto setCreatedAt(OffsetDateTime createdAt) {
		this.createdAt = createdAt;
		return this;
	}
}
