package com.example.masterjava.exceptions;

public class NotFoundException extends ApiException {
	private final Long id;

	public NotFoundException(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}
}
