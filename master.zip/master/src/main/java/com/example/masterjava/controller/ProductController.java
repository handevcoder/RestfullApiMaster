package com.example.masterjava.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.masterjava.dto.ProductDto;
import com.example.masterjava.exceptions.BeanValidationException;
import com.example.masterjava.services.ProductService;


@RestController
@RequestMapping("/pruducts")
public class ProductController {

	private final MessageSource messageSource;
	private final ProductService productService;
		
	public ProductController(MessageSource messageSource, ProductService productService) {
		this.messageSource = messageSource;
		this.productService = productService;			
	}
	
	@GetMapping
	public List<ProductDto> findById(){
		return this.productService.findAll();
	}
	
	@PostMapping
	public ResponseEntity<ProductDto> create(@RequestBody @Valid ProductDto productDto, BindingResult bindingResult){
		return null;
//		if (bindingResult.hasErrors()) {
//			throw new BeanValidationException(bindingResult);
//		}
//		
//		var createdProductDto = this.productService.create(productDto);
//		var uri = UriUtil.path("/{id}", createdProductDto.getId());
//		
//		return ResponseEntity.created(uri).
	}
}
