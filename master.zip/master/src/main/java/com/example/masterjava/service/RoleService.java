package com.example.masterjava.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.masterjava.entity.Role;
import com.example.masterjava.repository.RoleRepository;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import com.example.masterjava.repository.RoleRepository;

@Service
public class RoleService {
	
//	public void setDataSource(DataSource ds);
//	public void create(String id);
//	public Role getRoleById(Long id);
//	public List<Role> getAllRole();
	
	
	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	@PersistenceContext
	private EntityManager em;

//	public ArrayList<Role> getAllRole() {
//		return roleRepository.getAllRole();
//	}


	public List<Role> getAllRole(){
		List<Role> resultList = em.createNamedStoredProcedureQuery("SP_GET_ALL_ROLE").getResultList();
		return resultList;
	}
//	
//	public List<Role> getRoleByName(String name){
//		return em.createNamedStoredProcedureQuery("SP_GET_ROLE_BYNAME").setParameter("P_RNAME", name).getResultList();
//	}	
}
