package com.example.masterjava.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.masterjava.entity.Role;
import com.example.masterjava.service.RoleService;


@RestController
public class RoleController {
	
	@Autowired
	private RoleService roleService;
	
	@PostMapping("/get-all-role")
	public List<Role> getAllRole(){
		List<Role> result = roleService.getAllRole();
		return result;
	}
	
//	@PostMapping(path = "/api/role-by-name")
//	public List<Role> getRoleByName(@RequestParam("name") String name){
//		return roleService.getRoleByName(name);
//	}
	
}
