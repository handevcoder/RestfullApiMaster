package com.example.masterjava.services;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.masterjava.dto.ProductDto;
import com.example.masterjava.mapper.ProductMapper;
import com.example.masterjava.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	
	private final ProductMapper productMapper;
	private final ProductRepository productRepository;
	
	public ProductServiceImpl(ProductMapper productMapper, ProductRepository productRepository) {
		this.productMapper = productMapper;
		this.productRepository = productRepository;
	}
	
	@Override
	public List<ProductDto> findAll() {
		// TODO Auto-generated method stub
		return this.productRepository.findAll().stream()
				.map(this.productMapper::EntityToDto)
				.collect(Collectors.toList());
	}
	

	@Override
	public Optional<ProductDto> findById(Long id) {
		// TODO Auto-generated method stub
		return this.productRepository.findById(id)
				.map(this.productMapper::EntityToDto);
	}

	@Override
	public ProductDto create(ProductDto productDto) {
		// TODO Auto-generated method stub
		productDto.setId(null);
		
		if (productDto.getCreatedAt() == null) {
			productDto.setCreatedAt(OffsetDateTime.now());
		}
		
		var newProduct = this.productMapper.DtoToEntity(productDto);
		var createdProduct = this.productRepository.save(newProduct);
		
		return this.productMapper.EntityToDto(createdProduct);
	}

	@Override
	public ProductDto update(ProductDto productDto) {
		var productUpdate = this.productMapper.DtoToEntity(productDto);
		var updateProduct = this.productRepository.save(productUpdate);
		
		return this.productMapper.EntityToDto(updateProduct);
	}

	@Override
	public void deleteById(Long id) {
		this.productRepository.deleteById(id);
	}
	
}
