package com.example.masterjava.service;

import java.util.List;

import javax.sql.DataSource;

import com.example.masterjava.entity.User;

public interface UserDao {
	public void setDataSource(DataSource ds);
	public void create(
			Long id, 
			String first_name, 
			String last_name, 
			String email, 
			String status
			);
	public User getUser(Integer id);
	public List<User> listUsers();
}
