package com.example.masterjava.exception;

import java.util.Date;

public class ErrorDetails {
//	"timestamp": "2021-08-31T15:55:08.611+00:00",
//	  "status": 404,
//	  "error": "Not Found",
//	  "message": "No message available",
//	  "path": "/masterjava/api/v1/users/100"
	
	private Date timestamp;
	private Long status;
	private String error;
	private String message;
	private String path;
	
	
	
	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public ErrorDetails(Date timestamp, Long status, String error, String message, String path) {
		//	public ErrorDetails(Date timestamp, Long status, String error, String message, String path) {
			
		super();
		this.timestamp = timestamp;
		this.status = status;
		this.error = error;
		this.message = message;
		this.path = path;		
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

}
