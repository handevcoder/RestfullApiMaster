package com.example.masterjava.exceptions;

public class ApiException extends RuntimeException {}
