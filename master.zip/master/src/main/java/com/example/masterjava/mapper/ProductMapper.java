package com.example.masterjava.mapper;

import org.springframework.stereotype.Component;

import com.example.masterjava.dto.ProductDto;
import com.example.masterjava.entity.Product;

@Component
public class ProductMapper {
	public ProductDto EntityToDto(Product product) {
		return new ProductDto()
				.setId(product.getId())
				.setName(product.getName())
				.setDecription(product.getDecription())
				.setPrice(product.getPrice())
				.setQuantity(product.getQuantity())
				.setCreatedAt(product.getCreatedAt());
	}
	
	public Product DtoToEntity(ProductDto productDto) {
		return new Product()
				.setId(productDto.getId())
				.setName(productDto.getName())
				.setDecription(productDto.getDecription())
				.setPrice(productDto.getPrice())
				.setQuantity(productDto.getQuantity())
				.setCreatedAt(productDto.getCreatedAt());
	}
	
}
